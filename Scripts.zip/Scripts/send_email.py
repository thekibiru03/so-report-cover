# Description:
# This grabs the newest file in the current folder and emails it using smtplib module
# In this context, this file is a zipped file containing a CSV report with Suricata events for the last 12 hrs
# 4ntiG0nu5

#import modules

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import os.path
import glob
import sys

#Get current path
path = os.getcwd()
os.chdir(path)
files = sorted(os.listdir(os.getcwd()), key=os.path.getmtime)

#Get newst file
newest = files[-1]

#Define email recipients
recipients = ['joseph.gitonga@serianu.com', 'sc3.support@serianu.com' , 'martin.mwangi@serianu.com']

#Email sending function

def send_email(email_recipient,
               email_subject,
               email_message,
               attachment_location = ''):

    email_sender = 'sc3.support@serianu.com'

    msg = MIMEMultipart()
    msg['From'] = email_sender
    msg['To'] = ", ".join(recipients)
    msg['Subject'] = email_subject

    msg.attach(MIMEText(email_message, 'plain'))

    if attachment_location != '':
        filename = os.path.basename(attachment_location)
        attachment = open(attachment_location, "rb")
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition',
                        "attachment; filename= %s" % filename)
        msg.attach(part)

    try:
        server = smtplib.SMTP('smtp.office365.com', 587)
        server.ehlo()
        server.starttls()
        server.login('sc3.support@serianu.com', 'Koh44715')
        text = msg.as_string()
        server.sendmail(email_sender, email_recipient, text)
        #print('email sent')
        server.quit()
    except:
        print("SMTP server connection error")
    return True

#Send email

send_email(recipients,
           'Suricata IDS Report[SOC]',
           'Hi Team, \nPlease find attached Suricata IDS Report \n \n \nTime covered: Last 12 hours\n\n\n***This email is automatically generated*** \n \n \n \n--END OF NOTIFICATION--',
          newest)

#Gracefully exit
sys.exit()
